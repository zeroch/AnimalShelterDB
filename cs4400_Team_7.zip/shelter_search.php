

<h1>
Atlanta Pet Adoption Consortium
</h1>

<hr>
<p1> Shelter Search</p1><br/>

<p2 style="margin-left: 50px"> Enter Zip Code </p2>
<form action="shelter_search_result.php" method="get">
<input type="text" name="zip"/>
<input type="submit"/>
</form>
 <button type="button" onclick="location.href='guest_main.php'">Back</button>
 



